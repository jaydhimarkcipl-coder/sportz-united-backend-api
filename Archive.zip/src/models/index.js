const { sequelize } = require('../config/database');

const User = require('./User');
const Player = require('./Player');
const Arena = require('./Arena');
const Sport = require('./Sport');
const Court = require('./Court');
const CourtSlot = require('./CourtSlot');
const Booking = require('./Booking');
const BookingDetail = require('./BookingDetail');
const BookingPlayer = require('./BookingPlayer');
const Amenity = require('./Amenity');
const ArenaAmenity = require('./ArenaAmenity');
const ArenaSport = require('./ArenaSport');
const PlayerWallet = require('./PlayerWallet');
const Transaction = require('./Transaction');
const RefreshToken = require('./RefreshToken');
const PlayerRefreshToken = require('./PlayerRefreshToken');
const UserDevice = require('./UserDevice');
const PromoCode = require('./PromoCode');
const Tournament = require('./Tournament');
const TournamentRegistration = require('./TournamentRegistration');
const TournamentParticipant = require('./TournamentParticipant');
const WhatsAppLog = require('./WhatsAppLog');

// --- Associations ---

// User & Arena
User.hasMany(Arena, { foreignKey: 'OwnerUserId' });
Arena.belongsTo(User, { foreignKey: 'OwnerUserId' });

// Arena & Court
Arena.hasMany(Court, { foreignKey: 'ArenaId' });
Court.belongsTo(Arena, { foreignKey: 'ArenaId' });

// Sport & Court
Sport.hasMany(Court, { foreignKey: 'SportId' });
Court.belongsTo(Sport, { foreignKey: 'SportId' });

// Court & CourtSlot
Court.hasMany(CourtSlot, { foreignKey: 'CourtId' });
CourtSlot.belongsTo(Court, { foreignKey: 'CourtId' });

// Player & Booking
Player.hasMany(Booking, { foreignKey: 'PlayerId' });
Booking.belongsTo(Player, { foreignKey: 'PlayerId' });

// Court & Booking
Court.hasMany(Booking, { foreignKey: 'CourtId' });
Booking.belongsTo(Court, { foreignKey: 'CourtId' });

// Booking & BookingDetail
Booking.hasMany(BookingDetail, { foreignKey: 'BookingId' });
BookingDetail.belongsTo(Booking, { foreignKey: 'BookingId' });

// CourtSlot & BookingDetail
CourtSlot.hasMany(BookingDetail, { foreignKey: 'SlotId' });
BookingDetail.belongsTo(CourtSlot, { foreignKey: 'SlotId' });

// Booking & BookingPlayer
Booking.hasMany(BookingPlayer, { foreignKey: 'BookingId', onDelete: 'NO ACTION' });
BookingPlayer.belongsTo(Booking, { foreignKey: 'BookingId', onDelete: 'NO ACTION' });

// Player & BookingPlayer
Player.hasMany(BookingPlayer, { foreignKey: 'PlayerId', onDelete: 'NO ACTION' });
BookingPlayer.belongsTo(Player, { foreignKey: 'PlayerId', onDelete: 'NO ACTION' });

// Arena & ArenaAmenity
Arena.hasMany(ArenaAmenity, { foreignKey: 'arenaId' });
ArenaAmenity.belongsTo(Arena, { foreignKey: 'arenaId' });

// Amenity & ArenaAmenity
Amenity.hasMany(ArenaAmenity, { foreignKey: 'amenityId' });
ArenaAmenity.belongsTo(Amenity, { foreignKey: 'amenityId' });

// Arena & ArenaSport
Arena.belongsToMany(Sport, { through: ArenaSport, foreignKey: 'arenaId' });
Sport.belongsToMany(Arena, { through: ArenaSport, foreignKey: 'sportId' });
Arena.hasMany(ArenaSport, { foreignKey: 'arenaId' });
ArenaSport.belongsTo(Arena, { foreignKey: 'arenaId' });
Sport.hasMany(ArenaSport, { foreignKey: 'sportId' });
ArenaSport.belongsTo(Sport, { foreignKey: 'sportId' });

// Player & PlayerWallet
Player.hasOne(PlayerWallet, { foreignKey: 'PlayerId' });
PlayerWallet.belongsTo(Player, { foreignKey: 'PlayerId' });

// Player & RefreshToken
Player.hasMany(PlayerRefreshToken, { foreignKey: 'PlayerId', as: 'RefreshTokens' });
PlayerRefreshToken.belongsTo(Player, { foreignKey: 'PlayerId', as: 'Player' });

// Booking & Transaction
Booking.hasMany(Transaction, { foreignKey: 'BookingId', onDelete: 'NO ACTION' });
Transaction.belongsTo(Booking, { foreignKey: 'BookingId', onDelete: 'NO ACTION' });

// Player & Transaction
Player.hasMany(Transaction, { foreignKey: 'PlayerId', onDelete: 'NO ACTION' });
Transaction.belongsTo(Player, { foreignKey: 'PlayerId', onDelete: 'NO ACTION' });

// User & RefreshToken
User.hasMany(RefreshToken, { foreignKey: 'UserId', as: 'RefreshTokens' });
RefreshToken.belongsTo(User, { foreignKey: 'UserId', as: 'User' });

// User & Arena (Staff context)
User.belongsTo(Arena, { foreignKey: 'ArenaId', as: 'Arena' });
Arena.hasMany(User, { foreignKey: 'ArenaId', as: 'Staff' });

// Arena & PromoCode
Arena.hasMany(PromoCode, { foreignKey: 'ArenaId' });
PromoCode.belongsTo(Arena, { foreignKey: 'ArenaId' });

// Arena & PlayerWallet
Arena.hasMany(PlayerWallet, { foreignKey: 'ArenaId' });
PlayerWallet.belongsTo(Arena, { foreignKey: 'ArenaId' });

// UserDevice & User/Player
User.hasMany(UserDevice, { foreignKey: 'UserId' });
UserDevice.belongsTo(User, { foreignKey: 'UserId' });

Player.hasMany(UserDevice, { foreignKey: 'PlayerId' });
UserDevice.belongsTo(Player, { foreignKey: 'PlayerId' });

// --- Tournament Associations ---

// Sport & Tournament
Sport.hasMany(Tournament, { foreignKey: 'SportId' });
Tournament.belongsTo(Sport, { foreignKey: 'SportId' });

// Arena & Tournament
Arena.hasMany(Tournament, { foreignKey: 'ArenaId' });
Tournament.belongsTo(Arena, { foreignKey: 'ArenaId' });

// Tournament & Registration
Tournament.hasMany(TournamentRegistration, { foreignKey: 'TournamentId' });
TournamentRegistration.belongsTo(Tournament, { foreignKey: 'TournamentId' });

// Player & Registration
Player.hasMany(TournamentRegistration, { foreignKey: 'PlayerId' });
TournamentRegistration.belongsTo(Player, { foreignKey: 'PlayerId' });

User.hasMany(Tournament, { foreignKey: 'CreatedBy' });
Tournament.belongsTo(User, { foreignKey: 'CreatedBy', as: 'Creator' });

// TournamentRegistration & Participant
TournamentRegistration.hasMany(TournamentParticipant, { foreignKey: 'RegistrationId', as: 'Participants' });
TournamentParticipant.belongsTo(TournamentRegistration, { foreignKey: 'RegistrationId' });

// Player & Participant
Player.hasMany(TournamentParticipant, { foreignKey: 'PlayerId' });
TournamentParticipant.belongsTo(Player, { foreignKey: 'PlayerId', as: 'Player' });


module.exports = {
    sequelize,
    User,
    Player,
    Arena,
    Sport,
    Court,
    CourtSlot,
    Booking,
    BookingDetail,
    BookingPlayer,
    Amenity,
    ArenaAmenity,
    ArenaSport,
    PlayerWallet,
    Transaction,
    RefreshToken,
    PlayerRefreshToken,
    UserDevice,
    PromoCode,
    Tournament,
    TournamentRegistration,
    TournamentParticipant,
    WhatsAppLog
};
